﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Player : MonoBehaviour
{
    Vector2 position;
    public Rigidbody2D rb2d;
    public bool moveYeah = true;

    // Events that it can invoke
    OnStair onStair = new OnStair();
    OnEnemy onEnemy = new OnEnemy();
    OnCoin onCoin = new OnCoin();


    // Start is called before the first frame update
    void Start()
    {
        position = transform.position;
        rb2d = GetComponent<Rigidbody2D>();

        EventManager.AddOnStairInvoker(this);
        EventManager.AddOnEnemyInvoker(this);
        EventManager.AddOnCoinInvoker(this);
        //
    }

    // Functions to add listeners
    // Important for abstraction
    public void AddOnStairListener(UnityAction listener)
    {
        onStair.AddListener(listener);
    }

    public void AddOnEnemyListener(UnityAction listener)
    {
        onEnemy.AddListener(listener);
    }

    public void AddOnCoinListener(UnityAction listener)
    {
        onCoin.AddListener(listener);
    }

    // Update is called once per frame
    void Update()
    {
        // Code to move the player based on key presses
        float moveX = Input.GetAxis("X");
        float moveY = Input.GetAxis("Y");

        bool overlap;
        Vector2 pointA = position;
        Vector2 pointB = position;
        Vector2 originalposition = position;
        Vector2 newPosition = position;
        //ContactFilter2D contactFilter;
        Collider2D col;

        if (moveX != 0 && moveYeah)
        {
            position.x += .16f * moveX;

            //pointA.x = newPosition.x - 0.08f;
            //pointA.y = newPosition.y + 0.08f;
            //pointB.x = newPosition.x + 0.08f;
            //pointB.y = newPosition.y - 0.08f;

            moveYeah = false;
        }

        if (moveY != 0 && moveYeah)
        {
            position.y += .16f * moveY;

            //pointA.x = position.x - 0.08f;
            //pointA.y = newPosition.y + 0.08f;
            //pointB.x = newPosition.x + 0.08f;
            //pointB.y = newPosition.y - 0.08f;

            moveYeah = false;
        }

        // checks for overlap
        overlap = Physics2D.OverlapArea(pointA, pointB);
        col = Physics2D.OverlapPoint(newPosition, -1, -1);
        //print(col);

        if (col == null)
        {
            transform.position = position;
        }
        else
        {
            if (!col.CompareTag("Player"))
            {
                if (col.CompareTag("wall"))
                {
                    position = transform.position;
                }
                //print("AHHH");
                //position = transform.position;
                else
                {
                    transform.position = position;
                    if (col.CompareTag("Stair"))
                    {
                        onStair.Invoke();
                        position = new Vector2(-2.8f, -0.08f);
                    }
                    if (col.CompareTag("Enemy"))
                    {
                        if (Time.timeScale == 1)
                        {
                            onEnemy.Invoke();
                            Destroy(gameObject);
                        }

                    }
                    if (col.CompareTag("coin"))
                    {
                        onCoin.Invoke();
                    }
                }
            }
        }

        if (moveY == 0 && moveX == 0)
        {
            moveYeah = true;
        }


        //Vector2 under = transform.position;
        //Collider2D overStair = Physics2D.OverlapPoint(under);

        //if (overStair.CompareTag("Stair"))
        //{
        //    onStair.Invoke();
        //}

    }
}
