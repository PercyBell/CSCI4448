﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;

public static class WriteScores
{
    // Takes care of writeing scores when a game is "Saved" of finished
    public static void Write()
    {
        StreamWriter output = null;

        try
        {
            output = new StreamWriter(Path.Combine(Application.streamingAssetsPath, "scores.txt"));
            string text = scoreKeep.Coins.ToString() + "," + scoreKeep.Floors.ToString();
            output.WriteLine(text);
            output.Close();
        }
        catch(Exception e)
        {
            Debug.Log(e.Message);
        }
    }
}
