﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    Timer move;
    // Start is called before the first frame update
    void Start()
    {
        move = gameObject.AddComponent<Timer>();
        move.Duration = 1f;
        move.Run();

        move.AddTimerFinishedEventListener(Move);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // Chooses a random direction and tries to move there
    private void Move()
    {
        int direction = Random.Range(0, 4);
        //print(direction);

        Vector2 position = transform.position;
        Vector2 ogPos = transform.position;

        if (direction == 0)
        {
            position.x += 0.16f;
        }
        if (direction == 1)
        {
            position.y += 0.16f;
        }
        if (direction == 2)
        {
            position.x -= 0.16f;
        }
        if (direction == 3)
        {
            position.y -= 0.16f;
        }

        Collider2D col = Physics2D.OverlapPoint(position);

        if (col == null)
        {
            transform.position = position;
        }
        else
        {
            if (col.CompareTag("Player"))
            {
                transform.position = position;
            }
            if (col.CompareTag("coin"))
            {
                transform.position = position;
            }
            else
            {
                transform.position = ogPos;
            }
        }



        move.Run();
    }
}
