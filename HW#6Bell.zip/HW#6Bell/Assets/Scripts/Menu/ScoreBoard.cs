﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreBoard : MonoBehaviour
{
    // Important for encapsulating and keeping track of the current score
    private static int coins;
    private static int floors;

    [SerializeField]
    GameObject FloorText;

    [SerializeField]
    GameObject CoinText;

    private static Text floorText;
    private static Text coinText;

    private string coinStart = "Coins: ";
    private string floorStart = "Floors: ";

    public int GetCoins
    {
        get { return coins; }
    }

    public int GetFloors
    {
        get { return floors; }
    }

    // Start is called before the first frame update
    void Start()
    {
        coins = 0;
        floors = 0;

        coinText = CoinText.GetComponent<Text>();
        floorText = FloorText.GetComponent<Text>();

        coinText.text = coinStart + coins.ToString();
        floorText.text = floorStart + floors.ToString();

        // Listen for onstair and oncoin to add points
        EventManager.AddOnstairListener(AddFloor);
        EventManager.AddOnCoinListener(AddCoin);
    }

    private void AddCoin()
    {
        //print("+= 1");
        coins += 1;
        coinText.text = coinStart + coins.ToString();
        scoreKeep.AddCoin();
    }

    private void AddFloor()
    {
        floors += 1;
        floorText.text = floorStart + floors.ToString();
        scoreKeep.AddFloor();
    }
}
