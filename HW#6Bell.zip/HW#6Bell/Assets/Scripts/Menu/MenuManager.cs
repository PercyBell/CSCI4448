﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class MenuManager
{
    // Adds an interface for menus to call other scenes or
    // other menus based on button presses
    public static void GoToMenu(MenuName menu)
    {
        switch(menu)
        {
            // load game over
            case MenuName.GameOver:
                Object.Instantiate(Resources.Load("GameOverMenu"));
                break;

            case MenuName.Main: // load main
                SceneManager.LoadScene("mainMenu");

                break;

            case MenuName.Pause: // load pause

                Object.Instantiate(Resources.Load("PauseMenu"));

                break;
        }
    }
}
