﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class GameInitilizer : MonoBehaviour
{
    // This is the factory which creates the game board and populates it with 
    // enemies and coins

    // these keep track of possible rooms for each area
    [SerializeField]
    GameObject[] Prefs0;

    [SerializeField]
    GameObject[] Prefs1;

    [SerializeField]
    GameObject[] Prefs2;

    [SerializeField]
    GameObject[] Prefs3;

    [SerializeField]
    GameObject[] Prefs4;

    [SerializeField]
    GameObject[] Prefs5;

    [SerializeField]
    GameObject[] Prefs6;

    [SerializeField]
    GameObject[] Prefs7;

    [SerializeField]
    GameObject[] Prefs8;

    // Keeps track of the current board
    GameObject[] board = new GameObject[9];

    // Keeps track of the coins and enemies for population
    [SerializeField]
    GameObject PrefabCoin;

    [SerializeField]
    GameObject PrefabEnemy;

    [SerializeField]
    GameObject PrefabWall;

    // Start is called before the first frame update
    private void Start()
    {

        MakeBoard();
        Populate();
        EventManager.AddOnstairListener(OnStair);
    }

    // Update is called once per frame
    private void Update()
    {
        
    }

    // Generate the rooms for the map
    private void MakeBoard()
    {
        board[0] = Prefs0[Random.Range(0, 3)];
        board[1] = Prefs1[Random.Range(0, 3)];
        board[2] = Prefs2[Random.Range(0, 3)];
        board[3] = Prefs3[Random.Range(0, 3)];
        board[4] = Prefs4[Random.Range(0, 3)];
        board[5] = Prefs5[Random.Range(0, 3)];
        board[6] = Prefs6[Random.Range(0, 3)];
        board[7] = Prefs7[Random.Range(0, 3)];
        board[8] = Prefs8[Random.Range(0, 3)];

        float x = -1.28f;
        float y = 1.28f;
        float factor = 1.28f;

        float xpos = x;
        float ypos = y;
        int tile = 0;

        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                GameObject room = Instantiate(board[tile], new Vector2(xpos, ypos), transform.rotation);
                //print(xpos);
                //print(i+j);
                ypos = ypos - factor;
                tile++;
            }
            xpos = xpos + factor;
            ypos = y;
        }
    }

    // Clear the current map
    private void Clean()
    {
        GameObject[] rooms = GameObject.FindGameObjectsWithTag("room");
        GameObject[] coins = GameObject.FindGameObjectsWithTag("coin");
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");

        foreach (GameObject room in rooms)
        {
            Destroy(room);
        }
        foreach (GameObject coin in coins)
        {
            Destroy(coin);
        }
        foreach (GameObject enemy in enemies)
        {
            Destroy(enemy);
        }
    }

    // Add coins and enemies to the map
    private void Populate()
    {
        for (int i = 0; i<20; i++)
        {
            int type = Random.Range(0, 2);
            int signx = Random.Range(0, 2);
            int x = Random.Range(0, 11);
            int signy = Random.Range(0, 2);
            int y = Random.Range(0, 11);

            if (signx == 0)
            {
                signx = -1;
            }
            if (signy == 0)
            {
                signy = -1;
            }

            Vector2 pos = new Vector2(x*signx*0.16f+0.08f*signx, y*signy*0.16f + 0.08f * signy);

            Collider2D col = Physics2D.OverlapPoint(pos);

            if (col == null)
            {
                if (type == 0)
                {
                    GameObject coin = Instantiate(PrefabCoin, pos, transform.rotation);
                }
                if (type == 1)
                {
                    GameObject Enemy = Instantiate(PrefabEnemy, pos, transform.rotation);
                }
            }
        }
    }

    // If the player goes onto the stairs
    private void OnStair()
    {
        print("ONSTAIR");
        Clean();
        MakeBoard();
        Populate();
    }
}
