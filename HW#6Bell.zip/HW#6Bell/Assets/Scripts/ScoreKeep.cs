﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class scoreKeep
{
    private static int coins;
    private static int floors;

    public static int Coins
    {
        get { return coins; }
    }

    public static int Floors
    {
        get { return floors; }
    }

    public static void AddCoin()
    {
        coins += 1;
    }

    public static void AddFloor()
    {
        floors += 1;
    }
}
