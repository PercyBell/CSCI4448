﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class EventManager
{
    // keeps track of invokers and listeners for an event
    // Makes sure that there is abstraction between what is invoking events
    // and what is listening for events. So they dont have to know
    // that the other exists

    // on stair
    static List<Player> invokeOnStair = new List<Player>();
    static List<UnityAction> listenOnStair = new List<UnityAction>();

    // on enemy
    static List<Player> invokeOnEnemy = new List<Player>();
    static List<UnityAction> listenOnEnemy = new List<UnityAction>();

    // on coin
    static List<Player> invokeOnCoin = new List<Player>();
    static List<UnityAction> listenOnCoin = new List<UnityAction>();

    // --------------------- on stair
    public static void AddOnStairInvoker(Player script)
    {
        invokeOnStair.Add(script);
        foreach(UnityAction listener in listenOnStair)
        {
            script.AddOnStairListener(listener);
        }
    }

    public static void AddOnstairListener(UnityAction handler)
    {
        listenOnStair.Add(handler);
        foreach (Player player in invokeOnStair)
        {
            player.AddOnStairListener(handler);
        }
    }

    //------------------------  on enemy
    public static void AddOnEnemyInvoker(Player script)
    {
        invokeOnEnemy.Add(script);
        foreach (UnityAction listener in listenOnEnemy)
        {
            script.AddOnEnemyListener(listener);
        }
    }

    public static void AddOnEnemyListener(UnityAction handler)
    {
        listenOnEnemy.Add(handler);
        foreach (Player player in invokeOnEnemy)
        {
            player.AddOnEnemyListener(handler);
        }
    }

    //----------------------- on coin
    public static void AddOnCoinInvoker(Player script)
    {
        invokeOnCoin.Add(script);
        foreach (UnityAction listener in listenOnCoin)
        {
            script.AddOnCoinListener(listener);
        }
    }

    public static void AddOnCoinListener(UnityAction handler)
    {
        listenOnCoin.Add(handler);
        foreach (Player player in invokeOnCoin)
        {
            player.AddOnCoinListener(handler);
        }
    }
}
