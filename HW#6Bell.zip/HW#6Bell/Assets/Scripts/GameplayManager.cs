﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameplayManager : MonoBehaviour
{
    // Start is called before the first frame update
    private void Start()
    {
        EventManager.AddOnEnemyListener(GameOver);
    }

    // Update is called once per frame
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape) && Time.timeScale == 1)
        {
            MenuManager.GoToMenu(MenuName.Pause);
        }
    }

    // Load the gameover menu
    private void GameOver()
    {
        Time.timeScale = 0;

        Object.Instantiate(Resources.Load("GameOverMenu"));
    }
}
