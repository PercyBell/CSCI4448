﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    private Timer spin;
    private bool side = true;
    private SpriteRenderer SR;

    [SerializeField]
    Sprite flip;

    [SerializeField]
    Sprite norm;

    // Start is called before the first frame update
    void Start()
    {
        EventManager.AddOnCoinListener(Pickup);
        SR = GetComponent<SpriteRenderer>();
        spin = gameObject.AddComponent<Timer>();
        spin.Duration = 0.8f;
        spin.Run();

        spin.AddTimerFinishedEventListener(Flip);
    }

    private void Update()
    {
        //if (spin.Finished && !spin.Running)
        //{
        //    Flip();
        //}
    }
    // Update is called once per frame
    private void Pickup()
    {
        //Unfortunately I couldn't figure out how to avoid this...
        // but this is bad encapsulation because now the coin knows about the
        // player and its position. But I really couldnt figure out another way
        GameObject player = GameObject.FindWithTag("Player");

        //Collider2D col = Physics2D.OverlapPoint(transform.position);
        //print(col);
        if (player.transform.position == transform.position)
        {
            Destroy(gameObject);
        }
    }

    private void Flip()
    {
        if (side == true)
        {
            side = false;
            SR.sprite = flip;
        }
        else
        {
            side = true;
            SR.sprite = norm;
        }
        spin.Run();
    }
}
